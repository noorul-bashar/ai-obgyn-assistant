"""
Consultation — the front end for POST /api/v1/chat/.

Sends a clinician's free-text question + the active patient_id, and renders
the guarded answer exactly as the backend shapes it: answer, sources,
whether patient history was used, a disclaimer, and an escalation flag.
"""
import streamlit as st
from api_client import APIError
from utils import (
    PAGE_HISTORY,
    get_client,
    init_session_state,
    inject_css,
    render_disclaimer_banner,
    render_sidebar,
    require_active_patient,
)

st.set_page_config(page_title="Consultation · AI OB-GYN Assistant", page_icon="💬", layout="wide")

init_session_state()
inject_css()
render_sidebar()

st.title("💬 Consultation")
st.caption("Ask a clinical question. The backend retrieves relevant reference material and this patient's history, then applies safety guardrails before returning an answer.")

active = require_active_patient()
if not active:
    st.stop()

patient_id, patient_name = active

# ------------------------------------------------------------------ #
# header row: patient + clear chat
# ------------------------------------------------------------------ #
head_left, head_right = st.columns([4, 1])
with head_left:
    st.markdown(f"#### Consulting for **{patient_name}**")
with head_right:
    if st.button("🗑️ Clear chat", use_container_width=True):
        st.session_state.chat_histories[patient_id] = []
        st.rerun()

st.caption(
    "This conversation is **not** saved to the patient's record. If it should be, "
    "summarize the relevant parts into a visit entry on the Medical History page."
)

# ------------------------------------------------------------------ #
# quick patient context (most recent visits), collapsed by default
# ------------------------------------------------------------------ #
with st.expander("🗂️ Patient context (most recent visits)"):
    try:
        history = get_client().get_history(patient_id)
    except APIError as exc:
        history = None
        st.caption(f"Couldn't load history: {exc.message}")

    if history is not None:
        if not history:
            st.caption("No prior visits on record for this patient.")
        else:
            for entry in history[:3]:
                st.markdown(
                    f"**{entry['visit_date'][:10]}** — {entry['chief_complaint']}  \n"
                    f"<span class='obgyn-muted'>Diagnosis: {entry.get('diagnosis') or 'n/a'} · "
                    f"Treatment: {entry.get('treatment_plan') or 'n/a'}</span>",
                    unsafe_allow_html=True,
                )
            if len(history) > 3:
                st.caption(f"+ {len(history) - 3} more visit(s).")
        st.page_link(PAGE_HISTORY, label="Open full history", icon="📖")

st.divider()

# ------------------------------------------------------------------ #
# message rendering
# ------------------------------------------------------------------ #
chat_key = patient_id
st.session_state.chat_histories.setdefault(chat_key, [])


def render_message(msg: dict) -> None:
    with st.chat_message(msg["role"]):
        if msg.get("error"):
            st.error(msg["content"], icon="🚫")
            return

        st.markdown(msg["content"])

        if msg["role"] == "assistant":
            render_disclaimer_banner(msg.get("disclaimer", ""), msg.get("escalate", False))

            badge = "📋 Patient history was used" if msg.get("used_history") else "📋 No patient history was on file for this query"
            st.caption(badge)

            sources = msg.get("sources") or []
            if sources:
                with st.expander(f"📚 Sources ({len(sources)})"):
                    for s in sources:
                        score = s.get("relevance_score")
                        score_label = f"{score:.2f}" if isinstance(score, (int, float)) else "n/a"
                        st.markdown(f"**{s.get('document_id', 'unknown document')}** · relevance {score_label}")
                        st.caption(s.get("snippet", ""))
                        st.markdown("---")


for msg in st.session_state.chat_histories[chat_key]:
    render_message(msg)

if not st.session_state.chat_histories[chat_key]:
    st.info("Ask anything about this patient — e.g. symptom triage, guideline lookups, or a summary of their history.", icon="💡")

# ------------------------------------------------------------------ #
# quick-action suggestions
# ------------------------------------------------------------------ #
suggestions = [
    "Summarize this patient's history and any relevant risk factors.",
    "What follow-up questions should I ask this patient?",
    "What do current guidelines say about this patient's chief complaint?",
]
sug_cols = st.columns(len(suggestions))
for col, text in zip(sug_cols, suggestions):
    if col.button(text, use_container_width=True, key=f"sugg_{hash(text)}"):
        st.session_state.pending_message = text
        st.rerun()

# ------------------------------------------------------------------ #
# input handling
# ------------------------------------------------------------------ #
incoming = st.session_state.pop("pending_message", None)
typed = st.chat_input("Ask a clinical question about this patient...")
if typed:
    incoming = typed

if incoming:
    st.session_state.chat_histories[chat_key].append({"role": "user", "content": incoming})
    try:
        with st.spinner("Consulting the knowledge base and patient history..."):
            result = get_client().send_chat(patient_id, incoming)
        st.session_state.chat_histories[chat_key].append(
            {
                "role": "assistant",
                "content": result["answer"],
                "sources": result.get("sources", []),
                "disclaimer": result.get("disclaimer", ""),
                "escalate": result.get("escalate_to_clinician", False),
                "used_history": result.get("used_patient_history", False),
            }
        )
    except APIError as exc:
        st.session_state.chat_histories[chat_key].append(
            {"role": "assistant", "error": True, "content": exc.message}
        )
    st.rerun()
